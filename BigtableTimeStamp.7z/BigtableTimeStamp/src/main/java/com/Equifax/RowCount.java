package com.Equifax;

import java.io.IOException;
import com.google.cloud.bigtable.beam.CloudBigtableIO;
import com.google.cloud.bigtable.beam.CloudBigtableScanConfiguration;
import org.apache.beam.sdk.io.Read;
import org.apache.beam.sdk.io.TextIO;
import java.util.Calendar;
import java.util.Date;
import org.apache.beam.sdk.transforms.Count;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.options.PipelineOptionsFactory;

public class RowCount {
	
	 public static interface CountOptions extends CloudBigtableOptions {

		    void setResultLocation(String resultLocation);

		    String getResultLocation();
		  }

		  // Converts a Long to a String so that it can be written to a file.
		  static DoFn<Long, String> stringifier = new DoFn<Long, String>() {
		    private static final long serialVersionUID = 1L;

		    @ProcessElement
		    public void processElement(DoFn<Long, String>.ProcessContext context) throws Exception {
		      context.output(context.element().toString());
		    }
		  };

		  public static void main(String[] args) {
		    CountOptions options =
		        PipelineOptionsFactory.fromArgs(args).withValidation().as(CountOptions.class);
		    String PROJECT_ID = options.getProject();
		    String INSTANCE_ID = options.getBigtableInstanceId();
		    String TABLE_ID = options.getBigtableTableId();
		    Calendar cal=Calendar.getInstance();
			  cal.set(Calendar.DAY_OF_MONTH, 1);
			  long sd=cal.getTimeInMillis();
			  
			  Date dt=new Date();
			  Calendar c=Calendar.getInstance();
			  c.setTime(dt);
			  c.add(Calendar.DATE, 1);
			  long et=c.getTimeInMillis();
			  System.out.println(PROJECT_ID);
			  System.out.println(INSTANCE_ID);
			  System.out.println(TABLE_ID);
			  System.out.println(sd);
			  System.out.println(et);
		    // [START bigtable_dataflow_connector_scan_config]
		    Scan scan = new Scan();
		    scan.setCacheBlocks(false);
		    try {
				scan.setTimeRange(sd, et);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		    // CloudBigtableTableConfiguration contains the project, zone, cluster and table to connect to.
		    // You can supply an optional Scan() to filter the rows that will be read.
		    CloudBigtableScanConfiguration config =
		        new CloudBigtableScanConfiguration.Builder()
		            .withProjectId(PROJECT_ID)
		            .withInstanceId(INSTANCE_ID)
		            .withTableId(TABLE_ID)
		            .withScan(scan)
		            .build();

		    Pipeline p = Pipeline.create(options);

		    p.apply(Read.from(CloudBigtableIO.read(config)))
		        .apply(Count.<Result>globally())
		        .apply(ParDo.of(stringifier))
		        .apply(TextIO.write().to(options.getResultLocation()));
		    // [END bigtable_dataflow_connector_scan_config]

		    p.run().waitUntilFinish();

		    // Once this is done, you can get the result file via "gsutil cp <resultLocation>-00000-of-00001"
		  }
	

}
