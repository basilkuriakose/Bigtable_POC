package com.Equifax;

import static com.google.cloud.bigtable.data.v2.models.Filters.FILTERS;

import java.io.IOException;

import com.google.api.gax.rpc.ServerStream;
import com.google.cloud.bigtable.data.v2.BigtableDataClient;
import com.google.cloud.bigtable.data.v2.models.Query;
import com.google.cloud.bigtable.data.v2.models.Row;
import com.google.cloud.bigtable.data.v2.models.Filters.Filter;

public class RowCount {
	public static void main(String[] args) throws IOException 
	  {
		if (args.length != 5) {
		      System.out.println("Missing required project id or instance id or tableId or StartTime or EndTime");
		      return;
		    }
		    String projectId = args[0];
		    String instanceId = args[1];
		    String tableId=args[2];
		    Long StartTime=Long.parseLong(args[3]);
		    Long EndTime=Long.parseLong(args[4]);
		    System.out.println(projectId);
			  System.out.println(instanceId);
			  System.out.println(tableId);
			  System.out.println(StartTime);
			  System.out.println(EndTime);
		    Filter filter = FILTERS.timestamp().range().of(StartTime, EndTime);
			int count=readFilter(projectId, instanceId, tableId, filter);
			System.out.println(count);
	  }

	private static  int readFilter(String projectId, String instanceId, String tableId, Filter filter) {

		try (BigtableDataClient dataClient = BigtableDataClient.create(projectId, instanceId)) {
			  Query query = Query.create(tableId).filter(filter);
			  ServerStream<Row> rows = dataClient.readRows(query);
			
			  int count = 0;
			  for (Row row : rows)
			  {
			    	  ++count;
			  }
			  return count;
			  } 
			  catch (IOException e) {System.out.println("Unable to initialize service client, as a network error occurred: \n" + e.toString());}
		return 0;
	}
}
